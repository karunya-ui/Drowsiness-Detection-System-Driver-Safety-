#ifndef CONFIG_H
#define CONFIG_H

#define IR_SENSOR_PIN 34
#define BUZZER_PIN 25
#define CLOSED_TIME_THRESHOLD 3000   // 3 seconds

#endif
