# 🚗 Drowsiness Detection System using ESP32

## 📌 Overview
This project detects driver drowsiness using an IR Eye Blink Sensor.
If the driver's eyes remain closed for more than 3 seconds,
a buzzer alert is triggered.

## 🔧 Components Used
- ESP32
- IR Eye Blink Sensor
- Buzzer
- SIM800L GSM Module (Optional)

## 🧠 Working Principle
The IR sensor detects eye closure.
If eye closure exceeds threshold time,
the system activates buzzer.

## 🚀 Features
- Real-time monitoring
- Low-cost embedded solution
- Expandable with camera & AI

## 👩‍💻 Developed By
R. Karunya
ECE | Embedded Systems Enthusiast
